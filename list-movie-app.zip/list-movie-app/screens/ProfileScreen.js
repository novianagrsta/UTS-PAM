import React from 'react';
import { View, Text } from 'react-native';

const ProfileScreen = () => {
  return (
    <View>
      <Text>Profile Screen</Text>
      <Text>Name: Noviana Gresita Br. Perangin-Angin</Text>
      <Text>Email: noviana.120140239@student.itera.ac.id</Text>
    </View>
  );
}

export default ProfileScreen;
