# List-Movie app

1. Deskripsi:
Aplikasi mobile sederhana yang memuat list movie. Aplikasi ini terdiri dari tiga halaman, yaitu halaman utama yang menampilkan home screen, halaman detail item yang menampilkan informasi detail tentang movie, dan halaman pengaturan profil pengguna.

2. Untuk menjalankan aplikasi ini, ikuti langkah-langkah berikut:
- Install Node.js.
- Install Expo CLI dengan menjalankan perintah npm install -g expo-cli.
- Clone repository ini atau unduh file zip dan ekstrak.
- Masuk ke direktori aplikasi dan jalankan perintah npm install untuk menginstal semua dependensi.
- Jalankan perintah expo start untuk memulai server development Expo.
- Buka aplikasi Expo pada perangkat iOS atau Android, atau emulator.
- Scan kode QR yang muncul pada server development Expo untuk membuka aplikasi.
