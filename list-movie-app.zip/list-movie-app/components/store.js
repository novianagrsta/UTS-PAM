// Create store with reducer
const store = createStore(reducer);